//
//  ThirdViewController.swift
//  Contact in data dictionary
//
//  Created by agilemac-74 on 25/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblNumber: UILabel!
    
    var dictEmployeeToReceive:[String:Any] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()

        self.lblName.text = dictEmployeeToReceive["name"] as? String
        let inId = dictEmployeeToReceive["id"] as! Int
        let strId =  "\(inId)"
        self.lblNumber.text = strId
    }
    

   
}


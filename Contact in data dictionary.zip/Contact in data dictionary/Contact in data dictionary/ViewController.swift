//
//  ViewController.swift
//  Contact in data dictionary
//
//  Created by agilemac-74 on 25/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtNumber: UITextField!
    var dictEmployee:[String:Any] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
       doSetupUI()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if txtName.isFirstResponder{
            txtName.becomeFirstResponder()
        }
    }
    private func doSetupUI(){
        txtNumber.keyboardType = .numberPad
        
    }
    @IBAction func btnSave(_ sender: UIButton) {
        
        let strId = txtNumber.text!
        let intId = Int(strId)
        
        guard let intIdFinal = intId else{
            return
        }
        dictEmployee["id"] = intIdFinal
        dictEmployee["name"] = txtName.text!
    appDelegate.arrGlobalData.append(dictEmployee)
        
        let secondVC =
         self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController")as! SecondViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
    navigationController.pushViewController(secondVC, animated: true)
        txtName.text = ""
        txtNumber.text = ""
        
    }
    
    
}



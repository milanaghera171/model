//
//  SecondViewController.swift
//  Contact in data dictionary
//
//  Created by agilemac-74 on 25/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetUpUI()
     
    }
    private func doSetUpUI(){
    tableview.dataSource = self
    tableview.delegate = self
    
        let nibName = UINib(nibName: "TableViewCell", bundle: nil)
        tableview.register(nibName, forCellReuseIdentifier: "Cell")
        
        
        //MARK:-TITLE
        self.navigationItem.title = "Table Test"
        
        
        // BAR BUTTON ITEM
        
       
        
        
        let leftBarButtonItemBookmark = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.add, target: self, action: #selector(self.tabBarButton1))
        
        
        
        self.navigationItem.rightBarButtonItems = [leftBarButtonItemBookmark]
    }
    @objc func tabBarButton1(){
        print("Bar Button Pressed")
        let indexToInsertAt = 0
        let indexPathToInsertAt = IndexPath(row: indexToInsertAt, section: 0)
        
        tableview.insertRows(at: [indexPathToInsertAt], with: UITableViewRowAnimation.right)
    }
}
//MARK:- TableView DataSource
extension SecondViewController : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell",for: indexPath)as! TableViewCell
        
        let dictData = appDelegate.arrGlobalData[indexPath.row]
        
        cell.lblnamefortable.text = dictData["name"] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.arrGlobalData.count
    }
}
//MARK:- TableView Delegate
extension SecondViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let thirdVC =
        self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController")as! ThirdViewController

        guard let navigationController = self.navigationController else {
            return
        }
        
        thirdVC.dictEmployeeToReceive = appDelegate.arrGlobalData[indexPath.row]
        
        navigationController.pushViewController(thirdVC, animated: true)
        print("This is \(indexPath.row) Row")
    }
}


//
//  CustomTableViewCell.swift
//  ScroolViewDetailForm
//
//  Created by pc on 4/27/18.
//  Copyright © 2018 pcChetanAgile. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet var viewBack: UIView!
    
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblId: UILabel!
    @IBOutlet var lblDOB: UILabel!
    @IBOutlet var lblPhoneNo: UILabel!
    @IBOutlet var lblAddress: UILabel!
    @IBOutlet var lblCity: UILabel!
    @IBOutlet var lblGender: UILabel!
    @IBOutlet var lbl1: UILabel!
    
    
    var newEmail = String()
    var newName = String()
    var newNumber = String()
    var newAddress = String()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        
        viewBack.layer.cornerRadius = 5.0
        viewBack.layer.borderWidth = 0.5
        viewBack.layer.borderColor = UIColor.blue.cgColor
      
    }
    
    func updateStudentData(studentDetails: Student){
        
        lblId.text = "Id: \(String(describing: studentDetails.std_Id))"
        lblName.text = "Name: \(String(describing: studentDetails.std_Name))"
        lblPhoneNo.text = "PhoneNo: \(String(describing: studentDetails.std_Phone))"
        lblAddress.text = "Address: \(String(describing: studentDetails.std_Address))"
        lblDOB.text = "DOB: \(String(describing: studentDetails.std_Dob))"
        lblCity.text = "City: \(String(describing: studentDetails.std_City))"
        lblGender.text = "Gender: \(String(describing: studentDetails.std_Gender))"
      
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}

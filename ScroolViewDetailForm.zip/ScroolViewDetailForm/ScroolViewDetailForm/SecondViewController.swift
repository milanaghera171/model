//
//  SecondViewController.swift
//  ScroolViewDetailForm
//
//  Created by pc on 4/26/18.
//  Copyright © 2018 pcChetanAgile. All rights reserved.
//

import UIKit
import CoreData

class SecondViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout
{
    
    var objStuent = Student()
    //var objStuent:Student?

    
    var screenfrom:String = ""
    
    var arrIndex:Int = 0
    var arrData = [Any]()
    
    var blockbtnclick:((NSDictionary) -> Void)?
    
    var arrCity = [Any]()
    var selectedCity = ""
    var selectedDate = ""
    var selectedPlan = ""

    var blockEditbtnClick:((String,Int) -> Void)?
    
    var arrindex = ["1","2","3"]

    
    
    @IBOutlet var brnSave: UIButton!
    @IBOutlet var ScrollView: UIScrollView!
    
    @IBOutlet var txtid: UITextField!
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtPhoneNo: UITextField!
    @IBOutlet var txtAddress: UITextView!
    @IBOutlet var seGender: UISegmentedControl!
    
    
    @IBOutlet var lblAddress: UILabel!
    @IBOutlet var lblGender: UILabel!
    @IBOutlet var lblDOB: UILabel!
    @IBOutlet var lblCity: UILabel!
    
    @IBOutlet var Datepicker: UIDatePicker!
    
    @IBOutlet var CityPicker: UIPickerView!
    
    var strGender:String = String()
    var strDOB:String = String()
    var strImg1:String = String()
    
    var newId = String()
    var newName = String()
    var newPhoneNo = String()
    var newAddress = String()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
//        let dateFormatterGet = NSDateFormatter()
//
//        dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
//
//        let dateFormatterPrint = NSDateFormatter()
//        dateFormatterPrint.dateFormat = "MMM dd,yyyy"
//
//        let date: NSDate? = dateFormatterGet.dateFromString("2016-02-29 12:24:26")
//        print(dateFormatterPrint.stringFromDate(date!))
//
//        self.Datepicker.setDate(<#T##date: Date##Date#>, animated: <#T##Bool#>)
        

        
        if objStuent.objectID == nil {
            brnSave.setTitle("Save", for: .normal)
        }
        else
        {
            brnSave.setTitle("Update", for: .normal)
            

            
        }
        
        
        
//Update Button
    
//        let UpdateButton = UIBarButtonItem(title: "Update", style: UIBarButtonItemStyle.plain, target: self, action: Selector(("showEditing:")))
//
//
//
//        self.navigationItem.rightBarButtonItem = UpdateButton
        
//        var dicData = [String:Any]()
//        dicData = ["std_Id":txtid.text!,
//                   "std_Name":txtName.text!,
//                   "std_Phone":txtPhoneNo.text!,
//                   "std_Address":txtAddress.text!,
//                   "std_Dob": strDOB,
//                   "std_City": selectedCity,
//                   "std_Gender": strGender]
//
//        CoreDataServiceManager.storeStudent(StudentDetail: dicData)
    
        
//Date Picker
        
        let datePick = UIDatePicker()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        strDOB = formatter.string(from:datePick.date)
        
        ScrollView.contentSize = CGSize(width: self.view.frame.size.width, height: 574)
        
        CityPicker.delegate = self
        CityPicker.dataSource = self
        
        arrCity = ["Ahmedabad","pune","mumbai","channi"]

        
        self.CityPicker.selectRow(2, inComponent: 0, animated: true)


        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    @IBAction func valueChangGender(_ sender: Any) {
        
        
        print("Select Index: \((sender as AnyObject).selectedSegmentIndex)")
        if (sender as AnyObject).selectedSegmentIndex == 0
        {
            print("Male")
            strGender = "Male"
            
            
        }else
        {
            print("Female")
            strGender = "Female"
            
        }
    }
       
    
@IBAction func ActionDatepicker(_ sender: UIDatePicker) {
    
    print(sender.date)
    
    let formatter = DateFormatter()
    formatter.dateFormat = "dd-MM-yyyy"
    strDOB = formatter.string(from: (sender as AnyObject).date)
    }

    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return arrCity.count
        
       }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrCity[row] as? String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedCity = arrCity[row] as! String
    }
    
    
    @IBAction func ActionSave(_ sender: Any)
    {
        print("ObjID:\(objStuent.objectID)")
        
        if objStuent.objectID == nil {
            var dicData = [String:Any]()
            dicData = ["std_Id":txtid.text!,
                       "std_Name":txtName.text!,
                       "std_Phone":txtPhoneNo.text!,
                       "std_Address":txtAddress.text!,
                       "std_Dob": strDOB,
                       "std_City": selectedCity,
                       "std_Gender": strGender]
            
            CoreDataServiceManager.storeStudent(StudentDetail: dicData)
            
            navigationController?.popViewController(animated: true)
        }
        else
        {
            var dicData = [String:Any]()
            dicData = ["std_Id":txtid.text!,
                       "std_Name":txtName.text!,
                       "std_Phone":txtPhoneNo.text!,
                       "std_Address":txtAddress.text!,
                       "std_Dob": strDOB,
                       "std_City": selectedCity,
                       "std_Gender": strGender]
            
            CoreDataServiceManager.updateStudent(id: objStuent.objectID, dict: dicData)
            
            navigationController?.popViewController(animated: true)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FirstCollectionViewCell", for: indexPath) as! FirstCollectionViewCell
        
       cell.lblName.text = arrindex[indexPath.row]
       
        
        return cell
    
}

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        
        let width = (self.view.frame.size.width - 34) / 3 //some width
        
        let height = width //ratio
        
        return CGSize(width: width, height: height);
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        selectedPlan = arrindex[indexPath.row]
        var selectedCell:FirstCollectionViewCell = collectionView.cellForItem(at: indexPath) as! FirstCollectionViewCell
        selectedCell.contentView.backgroundColor = UIColor.red
        
        
//        let objstr = storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
//        objstr.getindexpath = indexPath.row+1
//
//       // navigationController?.pushViewController(objstr, animated: true)
////  objstr.tblView.reloadData()
//        navigationController?.pushViewController(objstr, animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        var selectedCell:FirstCollectionViewCell = collectionView.cellForItem(at: indexPath) as! FirstCollectionViewCell
        selectedCell.contentView.backgroundColor = UIColor.white
    }

}

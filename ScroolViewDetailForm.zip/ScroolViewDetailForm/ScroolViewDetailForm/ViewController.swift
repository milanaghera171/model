//
//  ViewController.swift
//  ScroolViewDetailForm
//
//  Created by pc on 4/26/18.
//  Copyright © 2018 pcChetanAgile. All rights reserved.
//

import UIKit
class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var getindexpath:Int?
    
    
    @IBOutlet var tblView: UITableView!
    
    var arrStudentList = [Student]()
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        tblView.register(UINib(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "CustomTableViewCell")
        tblView.register(UINib(nibName: "NumberTableViewCell", bundle: nil), forCellReuseIdentifier: "NumberTableViewCell")
        tblView.register(UINib(nibName: "FirstCollectionViewCell", bundle: nil), forCellReuseIdentifier: "FirstCollectionViewCell")

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewWillAppear(_ animated: Bool) {
        
        self.arrStudentList = CoreDataServiceManager.getStudent()
        tblView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func ActionAdd(_ sender: Any) {
        
        let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController
        controller?.screenfrom = "Add"
        navigationController?.pushViewController(controller!, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrStudentList.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 200
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell") as! CustomTableViewCell
        cell.updateStudentData(studentDetails: arrStudentList[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print("You selected cell #\(indexPath.row)!")
//        let indexPath = tableView.indexPathForSelectedRow!
//        let currentCell = tableView.cellForRow(at: indexPath)! as UITableViewCell
        
        let passing:SecondViewController = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController)!
        
        passing.objStuent = arrStudentList[indexPath.row]
        
        self.navigationController?.pushViewController(passing, animated: true)
       
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if (editingStyle == UITableViewCellEditingStyle.delete)
        {
            CoreDataServiceManager.deleteStudent(id: arrStudentList[indexPath.row].objectID)
            arrStudentList = CoreDataServiceManager.getStudent()
            tableView.reloadData()


        }
    }

    

}

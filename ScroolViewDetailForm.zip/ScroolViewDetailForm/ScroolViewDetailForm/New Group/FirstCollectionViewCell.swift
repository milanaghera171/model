//
//  FirstCollectionViewCell.swift
//  ScroolViewDetailForm
//
//  Created by pc on 03/05/18.
//  Copyright © 2018 pcChetanAgile. All rights reserved.
//

import UIKit

class FirstCollectionViewCell: UICollectionViewCell {
    @IBOutlet var ViewBack: UIView!
    
    @IBOutlet var lblName: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        ViewBack.layer.cornerRadius = 25
    }

    
}

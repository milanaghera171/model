//
//  NumberTableViewCell.swift
//  ScroolViewDetailForm
//
//  Created by pc on 03/05/18.
//  Copyright © 2018 pcChetanAgile. All rights reserved.
//

import UIKit

class NumberTableViewCell: UITableViewCell {

    @IBOutlet var lblnum: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

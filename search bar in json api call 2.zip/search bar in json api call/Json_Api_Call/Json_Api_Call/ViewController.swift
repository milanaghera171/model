//
//  ViewController.swift
//  Json_Api_Call
//
//  Created by agilemac-74 on 22/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
enum selectedScop:Int{
    case name = 0
}
class ViewController: UIViewController,UISearchBarDelegate {

    @IBOutlet var searchbar: UISearchBar!
    @IBOutlet var tableview: UITableView!
  
   var searchCountry = [String]()
    
    var searching = false
    override func viewDidLoad() {
        super.viewDidLoad()
       
        tableview.delegate = self
        tableview.dataSource = self
        searchbar.delegate = self
        searchbar.returnKeyType = UIReturnKeyType.done
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK:- submit button
    @IBAction func btnPress(_ sender: UIButton) {
       
        
        ServiceManager.shared.fetchDataFromApi(with:"https://restcountries.eu/rest/v2/all"){ (isSuccess, message, arrCountrys) in
            
            if isSuccess{
                DispatchQueue.main.async {
                    print("Countrys: \(arrCountrys)")
                  
                    self.tableview.reloadData()
                }
                
            }else{
                print("Error:\(message)")
  
            }
        }
    }
    //MARK:- search bar
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

    if searchText.isEmpty{
    arrModelCountrys = [AICountry]()
    tableview.reloadData()
    }else{
    filterTableView(ind: searchBar.selectedScopeButtonIndex,text: searchText)
    tableview.reloadData()
    }
}
func filterTableView(ind:Int,text:String){
    switch ind {
    case selectedScop.name.rawValue:
        
        arrModelCountrys = arrModelCountrys.filter({ (model) -> Bool in
            return model.name.lowercased().contains(text.lowercased())
        })
        searching = true
        tableview.reloadData()
    default:
        print("not value")
    }
    
}
    //MARK:- search bar cancel button
func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
   
            searchBar.text = ""


    ServiceManager.shared.fetchDataFromApi(with:"https://restcountries.eu/rest/v2/all"){ (isSuccess, message, arrCountrys) in
        
        if isSuccess{
            DispatchQueue.main.async {
                print("Countrys: \(arrCountrys)")
                self.tableview.reloadData()
            }
            
        }else{
            print("Error:\(message)")
            
        }
    }
    
}
}
extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

    return arrModelCountrys.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell =
            tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
     
            cell.lblCountry.text = "\(arrModelCountrys[indexPath.row].name)"

        return cell
    }

   
}
//MARK:- table view delegate
extension ViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        // set initial cell
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -400, 20, 0)
        cell.layer.transform = transform
        //Final set cell animation
        UIView.animate(withDuration: 1.0){
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
            
        }
        
    }
}


//
//  ServiceManager.swift
//  Json_Api_Call
//
//  Created by agilemac-74 on 22/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

struct AICountry {
    var name:String
}
var arrModelCountrys = [AICountry]()

class ServiceManager: NSObject {
    static let shared:ServiceManager = ServiceManager()
    typealias BlockCountry = ((Bool,String,[AICountry])->Void)
    
    func fetchDataFromApi(with urlstr:String, on completion:@escaping BlockCountry){
        
        guard let url = URL(string: urlstr)else
        {
            completion(false,"Unable to create url ",[])
            return
        }
        let datatask = URLSession.shared.dataTask(with: url){(data,response,error) in
            
            if let arr = error {
                completion(false,"Error:\(arr.localizedDescription)",[])
                return
            }
            
            if let data = data {
                
                do{
                    let arrJson = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
                    
                    if let arrJson = arrJson as? NSArray{
                        for eachDict in arrJson{
                            if let finalDict = eachDict as? [String:Any]{
                                let model = AICountry(name: finalDict["name"] as! String)
                                arrModelCountrys.append(model)
                            }else{
                                completion(false,"Something went wrong",[])
                            }
                        }
                        completion(true,"Successfully fetched all the countrie",arrModelCountrys)
                        
                    }
                    
                } catch {
                     completion(false, "Something went wrong",[])
                }
            }else{
                 completion(false, "Something went wrong",[])
            }
        }
        datatask.resume()
    }
}


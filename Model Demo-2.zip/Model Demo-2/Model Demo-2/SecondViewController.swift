//
//  SecondViewController.swift
//  Model Demo-2
//
//  Created by agilemac-74 on 02/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        
        let nibUser = UINib(nibName: "TableViewCell",bundle:nil)
        tableview.register(nibUser, forCellReuseIdentifier: "Cell")
        
        self.navigationItem.title = "Table Test"
    }
}
extension SecondViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.arrGlobalEmployees.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =
            self.tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! TableViewCell
        let modelEmployee = appDelegate.arrGlobalEmployees[indexPath.row]
        cell.lblNameForTableViewCell.text = modelEmployee.name
        return cell
    }
}

extension SecondViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let thirdVC =
            self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController")as! ThirdViewController
        guard let navigationController = self.navigationController else {
            return
        }
        thirdVC.modelEmployeeToRecive = appDelegate.arrGlobalEmployees[indexPath.row]
        navigationController.pushViewController(thirdVC, animated: true)
        print("This is\(indexPath.row) Row")
        
    }
}

//
//  ViewController.swift
//  Model Demo-2
//
//  Created by agilemac-74 on 02/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

struct ModelEmployee {
    var name:String
    var number:Int
    
    init() {
        self.name = ""
        self.number = 0
        
    }
   
    
}

class ViewController: UIViewController {

    @IBOutlet var txtNumber: UITextField!
    @IBOutlet var txtName: UITextField!
    
    var modelEmployee:ModelEmployee = ModelEmployee()
    override func viewDidLoad() {
        super.viewDidLoad()
       doSetUpUI()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if !txtName.isFirstResponder{
            txtName.becomeFirstResponder()
            
        }
    }

    func doSetUpUI(){
        txtNumber.keyboardType =  .numberPad
    }
    @IBAction func btnSave(_ sender: UIButton) {
        let strId = txtNumber.text!
        let intId = Int(strId)
        
        guard let intIdFinal = intId else{
        return
        }
        modelEmployee.name = txtName.text!
        modelEmployee.number = intIdFinal
        
        appDelegate.arrGlobalEmployees.append(modelEmployee)
        
        let secondVC =
            self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController")as! SecondViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        navigationController.pushViewController(secondVC, animated: true)
        
        txtName.text = ""
        txtNumber.text = ""
        
    }
    

}


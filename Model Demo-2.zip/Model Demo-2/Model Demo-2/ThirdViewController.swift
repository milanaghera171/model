//
//  ThirdViewController.swift
//  Model Demo-2
//
//  Created by agilemac-74 on 02/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet var lblNumber: UILabel!
    @IBOutlet var lblName: UILabel!
    
    var modelEmployeeToRecive:ModelEmployee = ModelEmployee()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblName.text = self.modelEmployeeToRecive.name
        
        let intId = self.modelEmployeeToRecive.number
        let strId = "\(intId)"
        
        self.lblNumber.text = strId

    }

    

}
